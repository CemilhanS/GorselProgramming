import sqlite3
from flask import Flask, render_template 

app = Flask(__name__)

data = []

def VeriAl():
    global data
    with sqlite3.connect('benz.db') as con:
        cur = con.cursor()
        cur.execute("select * from benz")
        data = cur.fetchall()
        for i in data:
            print(i)

@app.route("/index")
def index():
    MercedesCarTitle = [
        {
            'MercedesCarTitle': '1990 Model'
        },
        {
            'MercedesCarTitle': '1972 Model'
        }
    ]
    return render_template("index.html", MercedesCarTitle = MercedesCarTitle)

@app.route("/car")
def car():
    print("Welcome Benz <3")
    VeriAl()
    return render_template("car.html", veri = data)

@app.route("/contact")
def contact():
    print("Welcome Contact")
    return render_template("contact.html")

if __name__ == "__main__":
    app.run(debug=True)